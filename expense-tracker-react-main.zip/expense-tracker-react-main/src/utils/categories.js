const categories = [
  { name: 'Compras' },
  { name: 'Alimentação' },
  { name: 'Salário' },
  { name: 'Carro' },
  { name: 'Lazer' },
  { name: 'Estudos' }
]

export default categories
