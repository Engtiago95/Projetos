import * as S from './styles'

const Laoding = () => {
  return (
    <S.Container>
      <div className="loading"></div>
    </S.Container>
  )
}

export default Laoding
