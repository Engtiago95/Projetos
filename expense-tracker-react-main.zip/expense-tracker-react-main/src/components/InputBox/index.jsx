import * as S from './styles'

const InputBox = ({ children }) => {
  return <S.Container>{children}</S.Container>
}

export default InputBox
