const theme = {
  colors: {
    backgroundColor: '#1E1E1E',
    contentColor: '#171717',
    boxColor: '#292929',
    green: '#12A454',
    white: '#F1F1F1'
  }
}

export default theme
